package Package;

public class Array_GivenValue {

	public static void main(String[] args) {
		int arr[]= {1,2,3,4,5,6,7,8,9};
		int m=14;
		boolean flag=false;
		
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==m) 
			{
				flag=true;
			}
			
		}
		if(flag) {
			System.out.println(m+" Element is present in Array");
		}
		else 
		{
			System.out.println(m+" Element is not present in array");
			
		}
		
		

	}

}
