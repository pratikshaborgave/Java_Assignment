package Package;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashMap_list {

	public static void main(String[] args) {
		Map<Integer,String> map = new HashMap<>();
		map.put(1,"Mango");
		map.put(2,"Apple");
		map.put(3,"Orange");
		map.put(4,"Banana");
		
		
		
		List<Integer>Key_list = new ArrayList(map.keySet());
		List<String>value_list = new ArrayList(map.values());
		System.out.println("key_List: "+Key_list);
		System.out.println("value_list: "+value_list);
		

	}

}
