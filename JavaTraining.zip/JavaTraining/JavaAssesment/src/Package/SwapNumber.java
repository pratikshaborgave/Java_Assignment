package Package;

public class SwapNumber {

	public static void main(String[] args) {
		
		//by temp variable
		int a=10;
		int b=20;
		int c;
		System.out.println("with temp variable");
		System.out.println("Before swaping");
		System.out.println("a="+a);
		System.out.println("b="+b);
		
		c=a;
		a=b;
		b=c;
		System.out.println("After swaping...");
		System.out.println("a="+a);
		System.out.println("b="+b);
		System.out.println();
		
		//without temp variable
		
		System.out.println("Without temp variable...");
		
		int x=50;
		int y=100;
		System.out.println("Before swaping");
		System.out.println("x="+x);
		System.out.println("y="+y);
		
		
		x=x+y;                //x=10+20=30
		y=x-y;                 //y=30-20=10
		x=x-y;                 //x=30-10=20
		
		System.out.println("After swaping...");
		System.out.println("x="+x);
		System.out.println("y="+y);
		

	}

}
