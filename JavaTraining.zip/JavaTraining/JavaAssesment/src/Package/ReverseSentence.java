package Package;

public class ReverseSentence {

	public static void main(String[] args) {
		String sentence="Java Program";
		String reversed=reverse(sentence);
		System.out.println("The reversed sentence is: "+reversed);
		

	}

	private static String reverse(String sentence) {
		if(sentence.isEmpty())
		{
			return sentence;
			
		}
		
		return reverse(sentence.substring(1))+sentence.charAt(0);
	}

}
