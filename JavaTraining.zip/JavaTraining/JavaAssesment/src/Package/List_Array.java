package Package;

import java.util.ArrayList;

public class List_Array {

	public static void main(String[] args) {
		ArrayList fruits = new ArrayList<>();
		//Element add in list
		 fruits.add("Mango");
		 fruits.add("Apple");
		 fruits.add("Orange");
		 fruits.add("banana");
		 
		 System.out.println("ArrayList: "+fruits);
		 
		 //create new array of string type
		 String [] arr = new String[fruits.size()];
		 
		 //Convert arraylist to string array(list-array)
		 fruits.toArray(arr);
		 System.out.println("Array: ");
		 for(String item:arr) {
			 System.out.println(item+", ");
		 }
		

	}

}
