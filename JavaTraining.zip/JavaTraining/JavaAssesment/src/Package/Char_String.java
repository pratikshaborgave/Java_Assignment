package Package;

public class Char_String {

	public static void main(String[] args) {
		char ch='a';
		System.out.println("***** Character to String *****");
		String str=Character.toString(ch);
		System.out.println("String is "+str);
		
		//String str2=String.valueOf(ch);
		//System.out.println("String is "+str2);
		System.out.println("***** String to Character *****");
		String s="Pratiksha";
		for(int i=0;i<s.length();i++)
		{
			char c = s.charAt(i);
			System.out.println("char "+c);
			
		}
		

	}

}
