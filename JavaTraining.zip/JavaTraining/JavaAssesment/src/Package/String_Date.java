package Package;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class String_Date {

	public static void main(String[] args) {
		String string="May 05,2022";
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("MMMM d,yyyy",Locale.ENGLISH);
		LocalDate date=LocalDate.parse(string,formatter);
		System.out.println(date);

	}

}
