package Package;

public class AddArray {

	public static void main(String[] args) {
		int row=2, column=2;
		int Mat1[][]= { {1,2},{3,4} };
		int Mat2[][]= { {1,2},{3,4} };
		int sum[][]= new int[row][column];
		
		for(int i=0;i<row;i++) 
		{
			for(int j=0;j<column;j++) 
			{
				sum[i][j]=Mat1[i][j]+Mat2[i][j];
				
			}
			
		}
		System.out.println("Sum of two Matrices: ");
		for(int[] rows : sum)
		{
            for (int columns : rows)
            {
                System.out.print(columns + "    ");
            }
            System.out.println();
		
		}

	}

}
