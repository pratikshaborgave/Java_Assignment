package Package;

import java.util.ArrayList;
import java.util.List;

public class JoinList {

	public static void main(String[] args) {
		

		List<Integer> list1= new ArrayList<>();
		list1.add(1);
		list1.add(2);
		list1.add(3);
		list1.add(4);
		System.out.println("First List is..");
		System.out.println(list1);
		

		List<Integer> list2= new ArrayList<>();
		list2.add(5);
		list2.add(6);
		list2.add(7);
		list2.add(8);
		System.out.println("Second List is..");
		System.out.println(list2);
		
		List<Integer> joinlist= new ArrayList<>();
		joinlist.addAll(list1);
		joinlist.addAll(list2);
		
		
		System.out.println("Joined list is "+joinlist);
	}

}
