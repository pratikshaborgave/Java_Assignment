package Package;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Array_list {

	public static void main(String[] args) {
		String[] array= {"Mango","Apple","Orange","Banana"};
		System.out.println("Array: "+Arrays.toString(array));
		
		//convert array to list
		List fruits= new ArrayList<>(Arrays.asList(array));
		System.out.println("List: "+fruits);

	}

}
