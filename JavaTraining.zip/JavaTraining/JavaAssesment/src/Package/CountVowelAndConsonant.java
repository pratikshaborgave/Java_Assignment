package Package;

public class CountVowelAndConsonant {

	public static void main(String[] args) {
		int vowels_count=0, consonant_count=0;
		String str="This is Java programing.";
		str =str.toLowerCase();
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='a'||str.charAt(i)=='e'||str.charAt(i)=='i'||str.charAt(i)=='o'||str.charAt(i)=='u') 
			{
				vowels_count++;
				
			}
			
			else if(str.charAt(i)>='A'&&str.charAt(i)<='z')
			{
				consonant_count++;
				
			}
			
		}
		System.out.println("Number of Vowels: "+vowels_count);
		System.out.println("Number of Consonant: "+consonant_count);

	}

}
