package Package;

public class PrimeOrNot {

	public static void main(String[] args)
	{
		int flag=0;
		int num=32;
		if(num>1)
		{
			for(int i=2;i<num;i++) 
			{
				if(num%i==0) 
				{
					flag=1;
					
				}
			}
		}
		if(flag==1) {
			System.out.println("Number is not prime.");
		}
		else {
			System.out.println("Number is prime.");
		}

	}

}
