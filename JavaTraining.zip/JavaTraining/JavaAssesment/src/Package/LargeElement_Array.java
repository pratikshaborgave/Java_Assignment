package Package;

public class LargeElement_Array {

	public static void main(String[] args) {
		int arr[]= {1,3,4,5,67,879,5,34,26,7,21,890,432,23};
		int max=arr[0];
		for(int i=0;i<arr.length;i++) 
		{
			if(arr[i]>max) {
				max=arr[i];
			}
			
		}
		System.out.println(max+" is large element.");

	}

}
