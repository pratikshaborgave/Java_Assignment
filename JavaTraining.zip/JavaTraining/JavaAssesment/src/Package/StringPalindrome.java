package Package;

public class StringPalindrome {
	public static void main(String[] args) 
	{
		String str= "aba", nstr="";
        char ch;
       
      System.out.print("Original String: ");
      System.out.println("aba"); //Example word
       
      for (int i=0; i<str.length(); i++)
      {
        ch= str.charAt(i); //extracts each character
        nstr= ch+nstr; //adds each character in front of the existing string
      }
      System.out.println("Reversed String: "+ nstr);
     
      if("str"=="nstr") {
    	  System.out.println("String is palindrome");
      }
      else {
    	  System.out.println("String is not palindrome");
      }
	}

}
