package Package;

import java.lang.reflect.Array;
import java.util.Arrays;

public class ArrayConcatenate {

	public static void main(String[] args) {
		int arr1[]= {1,2,3};
		int arr2[]= {4,5,6,7};
		int a=arr1.length;
		int b=arr2.length;
		int c1=a+b;
		int c[]=new int[c1];
		
		System.arraycopy(arr1, 0, c, 0, a);
		System.arraycopy(arr2, 0, c, a, b);
		
		System.out.println(Arrays.toString(c));
		
	}

}
