package Package;

public class CharacterFromA_Z {

	public static void main(String[] args) {
		char i;
		System.out.println("capital letters-");
		for(i='A';i<='Z';i++)
		{
			
			System.out.println(i);
			
			
		}
		System.out.println(" ");
		System.out.println("Small Letters-");
		
		for(i='a';i<='z';i++)
		{
			
			System.out.println(i);
			
		}

	}

}
