package Package;

public class Pyramid_pattern {

	public static void main(String args[]) {
		int i,j,row=6;
		
		//outer loop for rows
		for(i=0;i<row;i++)
		{
			//inner loop for space
			for(j=row-i;j>1;j--)
			{
				//space between two stars
				System.out.print(" ");
				
				
			}
			//inner loop for columns
			for(j=0;j<=i;j++) 
			{
				//print *
				System.out.print("* ");
				
			}
			//new line
			System.out.println();
			
		}
	}

}
