package Package;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Digitfromalphanumericstring {

	public static void main(String[] args) {
		String str="hello 12 worl93 djhd 73";
		Pattern pattern = Pattern.compile("\\w+[0-9]+)\\w+([0-9]+)");
		Matcher matcher = pattern.matcher(str);
		for(int i=0;i<matcher.groupCount();i++)
		{
			matcher.find();
			System.out.println(matcher.group());
			
		}

	}

}
