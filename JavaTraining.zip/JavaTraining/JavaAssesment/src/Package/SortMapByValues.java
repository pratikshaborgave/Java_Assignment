package Package;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class SortMapByValues {
	
	
	public static HashMap<String, Integer>
    sortByValue(HashMap<String, Integer> fruit)
    {
        // Create a list from elements of HashMap
        List<Map.Entry<String, Integer> > list= new LinkedList<Map.Entry<String, Integer> >(fruit.entrySet());
 
        // Sort the list using lambda expression
        Collections.sort(list,(i1,i2) -> i1.getValue().compareTo(i2.getValue()));
 
        // put data from sorted list to hashmap
        HashMap<String, Integer> temp= new LinkedHashMap<String, Integer>();
        for (Map.Entry<String, Integer> aa : list) 
        {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }

	public static void main(String[] args) {
		
		HashMap<String, Integer> fruit= new HashMap<String, Integer>();

    // enter data into hashmap
    fruit.put("Apple",22);
    fruit.put("Mango",56 );
    fruit.put("Banana", 90);
    fruit.put("Grapes", 45);
    fruit.put("Orange", 756);
    fruit.put("PineApple", 85);
    fruit.put("Papaya", 65);
    fruit.put("Coconut", 80);
    fruit.put("Cherry", 102);
    fruit.put("Watermelon", 8);
    fruit.put("Peach", 33);
    Map<String, Integer> fruit1 = sortByValue(fruit);

    // print the sorted hashmap
    for (Map.Entry<String, Integer> en :
    	fruit1.entrySet()) {
        System.out.println("Key = " + en.getKey()+ ", Value = "+ en.getValue());
    }

	}

}
