package Inheritance;

class first {
    public void print_Java()
    {
        System.out.println("Java");
    }
}
 
class second extends first{
    public void print_program() { System.out.println("program"); }
}

public class a {

	public static void main(String[] args) {
		second g = new second();
        g.print_Java();
        g.print_program();
       

	}

}
