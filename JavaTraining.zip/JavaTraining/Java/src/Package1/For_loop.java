package Package1;

public class For_loop {

	public static void main(String[] args) {
		for(int a=1;a<=20;a++) {
			System.out.println(a);
		}
	}

}
