package Package1;

public class Decrement {

	public static void main(String[] args) {
		int a=5;
		int b=a--;
		System.out.println(b);
		
		int c=6;
		int d=--c;
		System.out.println(d);
		

	}

}
