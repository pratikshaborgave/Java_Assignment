package Package1;
import java.util.*;  
public class TreeSet {

	public static void main(String[] args) {
		TreeSet<String> al=new TreeSet<String>();  
		  al.add("Apple");  
		  al.add("Mango");  
		  al.add("Orange");  
		  al.add("Banana");  
		   
		  Iterator<String> itr=al.iterator();  
		  while(itr.hasNext()){  
		   System.out.println(itr.next());  
		  }  
		 }  
		
	

}
