package Package1;

public class Parameterized_constructor {
	
	int Emp_id;
	String Emp_name;
	

	public Parameterized_constructor(int i, String string) {
		Emp_id=i;
		Emp_name=string;
	}


	public static void main(String[] args) {
		Parameterized_constructor e1=new Parameterized_constructor(1254,"abc");
		Parameterized_constructor e2=new Parameterized_constructor(4524,"xyz");
		e1.display();
		e2.display();
	}


	private void display() {
		System.out.println(Emp_id+" "+Emp_name);
		
	}

}




