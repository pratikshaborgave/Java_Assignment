package Package1;

public class Constructor_Default {
	int Emp_id;
	String Emp_name;
	int Emp_id2;

	public static void main(String[] args) {
		Constructor_Default e1=new Constructor_Default();
		Constructor_Default e2=new Constructor_Default();
		Constructor_Default e3=new Constructor_Default();

		
		e1.display();
		e2.display();
		e3.display();

	}

	private void display() {
		System.out.println(Emp_id+" "+Emp_name);
	}

}



