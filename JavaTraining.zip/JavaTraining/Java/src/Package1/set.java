package Package1;

public class Set {

	public static void main(String[] args) {
		 Set<String> data = new LinkedHashSet<String>();   
		    
	        data.add("abc");   
	        data.add("pqr");   
	        data.add("lmn");   
	        data.add("xyz");   
	    
	        System.out.println(data);   
	    } 

}


