package Package1;

public class DoWhile_loop {

	public static void main(String[] args) {
		
		 int i=1;    
		    do{   
		    	System.out.println(i);
		    	i++;    
		    }while(i<=20);   
		
	}

}
