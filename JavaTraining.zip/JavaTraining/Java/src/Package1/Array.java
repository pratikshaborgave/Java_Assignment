package Package1;

public class Array {

	public static void main(String[] args) {
		int a[]=new int[10];  
		a[0]=10;  
		a[1]=20;  
		a[2]=70;  
		a[3]=40;  
		a[4]=50;
		a[5]=100;  
		a[6]=230;  
		a[7]=70;  
		a[8]=90;  
		a[9]=150;
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]); 
			
		}
		

	}

}
