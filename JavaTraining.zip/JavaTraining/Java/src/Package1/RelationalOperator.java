package Package1;

public class RelationalOperator {

	public static void main(String[] args) {
		int a = 23, b = 41;

	    
	    System.out.println("a is " + a + " and b is " + b);

	    // == Relational operator
	    System.out.println(a == b);  

	    // != Relational operator
	    System.out.println(a != b);  

	    // > Relational operator
	    System.out.println(a > b);  

	    // <  Relational operator
	    System.out.println(a < b);  

	    // >= Relational operator
	    System.out.println(a >= b);  

	    // <= Relational operator
	    System.out.println(a <= b);  

	}

}
