package Package1;

public class LogicalOperator {

	public static void main(String[] args) {
		// && Logical operator
	    System.out.println((50 > 33) && (34 >87));  
	    System.out.println((50 > 33) && (34 <87));  

	    // || Logical operator
	    System.out.println((985 < 23) || (24 > 5));  
	    System.out.println((4 > 6) || (8 < 5));  
	    System.out.println((3<9) || (8 < 5));  

	    // !Logical  operator
	    System.out.println(!(50 == 3));  
	    System.out.println(!(5 > 87));  

	}

}
