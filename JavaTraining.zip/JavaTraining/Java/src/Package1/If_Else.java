package Package1;

public class If_Else {

	public static void main(String[] args) {
		int a=23;
		int b=94;
		if(a>b)
		{
			System.out.println(a+" is greater than"+b);
			
		}
		else 
		{
			System.out.println(b+" is greater than"+a);
			
		}

	}

}
